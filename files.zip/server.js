// CampusPass backend v2: Express + sql.js (SQLite WASM). Run: npm install && npm start
const express = require('express');
const initSqlJs = require('sql.js');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// Load settings from a .env file next to server.js (KEY=value per line)
try {
  fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split(/\r?\n/).forEach(l => {
    const m = l.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  });
} catch (_) {}

const SECRET = process.env.JWT_SECRET || 'change-me-in-production';
const DB_FILE = path.join(__dirname, 'campuspass.db');
const MAX_CAP = 30; // events hold at most 30 guests

function createDbAdapter(SQL, rawDb) {
  let inTransaction = false;
  const persist = () => { if (!inTransaction) fs.writeFileSync(DB_FILE, Buffer.from(rawDb.export())); };
  const queryAll = (sql, params = []) => {
    const stmt = rawDb.prepare(sql);
    try {
      stmt.bind(params);
      const rows = [];
      while (stmt.step()) rows.push(stmt.getAsObject());
      return rows;
    } finally { stmt.free(); }
  };
  const queryOne = (sql, params = []) => { const rows = queryAll(sql, params); return rows.length ? rows[0] : undefined; };
  const runStmt = (sql, params = []) => {
    rawDb.run(sql, params);
    const changes = rawDb.getRowsModified();
    const row = queryOne('SELECT last_insert_rowid() AS id');
    persist();
    return { changes, lastInsertRowid: row ? row.id : 0 };
  };
  return {
    exec: (sql) => { rawDb.exec(sql); persist(); },
    pragma: (expr, opts = {}) => {
      const match = expr.match(/^([a-zA-Z0-9_]+)\s*(?:=\s*(.+))?$/);
      if (!match) return opts.simple ? undefined : [];
      const [, name, value] = match;
      if (value !== undefined) { rawDb.run(`PRAGMA ${name} = ${value}`); persist(); return undefined; }
      const rows = queryAll(`PRAGMA ${name}`);
      if (opts.simple) return rows.length ? rows[0][Object.keys(rows[0])[0]] : undefined;
      return rows;
    },
    prepare: (sql) => ({
      get: (...p) => queryOne(sql, p),
      all: (...p) => queryAll(sql, p),
      run: (...p) => runStmt(sql, p),
    }),
    transaction: (fn) => (...args) => {
      rawDb.run('BEGIN');
      inTransaction = true;
      try {
        const result = fn(...args);
        rawDb.run('COMMIT');
        inTransaction = false;
        persist();
        return result;
      } catch (err) {
        inTransaction = false;
        try { rawDb.run('ROLLBACK'); } catch (_) {}
        throw err;
      }
    },
  };
}

async function start() {
  const SQL = await initSqlJs();
  const fileBuffer = fs.existsSync(DB_FILE) ? fs.readFileSync(DB_FILE) : null;
  const rawDb = fileBuffer ? new SQL.Database(fileBuffer) : new SQL.Database();
  const db = createDbAdapter(SQL, rawDb);

  db.exec(`
  CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT, email TEXT UNIQUE, hash TEXT,
    role TEXT DEFAULT 'student', status TEXT DEFAULT 'active', created TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, organizer_id INTEGER, title TEXT, category TEXT,
    description TEXT, venue TEXT, date TEXT, price INTEGER DEFAULT 0, capacity INTEGER,
    status TEXT DEFAULT 'pending');
  CREATE TABLE IF NOT EXISTS bookings(id INTEGER PRIMARY KEY, event_id INTEGER, user_id INTEGER, qty INTEGER,
    code TEXT UNIQUE, status TEXT DEFAULT 'confirmed', checked_in INTEGER DEFAULT 0, created TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS invitations(id INTEGER PRIMARY KEY, event_id INTEGER, email TEXT, name TEXT, token TEXT UNIQUE,
    status TEXT DEFAULT 'pending', created TEXT DEFAULT CURRENT_TIMESTAMP, accepted_at TEXT, checked_in INTEGER DEFAULT 0);
  CREATE TABLE IF NOT EXISTS favorites(user_id INTEGER, event_id INTEGER, PRIMARY KEY(user_id,event_id));
  CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY, user_id INTEGER, text TEXT, link TEXT DEFAULT '',
    read INTEGER DEFAULT 0, created TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY, event_id INTEGER, user_id INTEGER, rating INTEGER, comment TEXT,
    created TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(event_id,user_id));
  CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, user_id INTEGER, action TEXT, at TEXT DEFAULT CURRENT_TIMESTAMP);
  `);
  try { db.exec('ALTER TABLE invitations ADD COLUMN checked_in INTEGER DEFAULT 0'); } catch (_) {} // older databases

  const seed = (n, e, r) => db.prepare('INSERT OR IGNORE INTO users(name,email,hash,role) VALUES(?,?,?,?)')
    .run(n, e, bcrypt.hashSync('password123', 8), r);
  seed('Admin', 'admin@campus.ac.ke', 'admin');
  seed('CS Club', 'organizer@students.ac.ke', 'organizer');
  seed('Amani Wanjiru', 'amani@students.ac.ke', 'student');

  if (!db.prepare('SELECT 1 FROM events').get()) {
    const ins = db.prepare('INSERT INTO events(organizer_id,title,category,description,venue,date,price,capacity,status) VALUES(2,?,?,?,?,?,?,?,?)');
    ins.run('Nairobi Tech Hackathon 2026', 'Tech', '9-hour build sprint with mentors and prizes.', 'Innovation Lab, Block B', '2026-12-17T09:00', 500, 30, 'published');
    ins.run('Afrobeats Night Live', 'Music', 'Live music at the amphitheatre.', 'Main Amphitheatre', '2026-12-23T19:00', 800, 25, 'published');
    ins.run('Founders Talk', 'Talk', 'Building in Africa.', 'Auditorium 2', '2026-12-09T16:00', 0, 20, 'published');
  }

  // Generate ~100 events spread over the next 12 months (runs once per database)
  if ((db.pragma('user_version', { simple: true }) || 0) < 2) {
    const names = {
      Tech: ['Hackathon', 'AI Workshop', 'Cybersecurity Bootcamp', 'Flutter Meetup', 'Cloud Computing Talk', 'Robotics Showcase'],
      Music: ['Afro Fusion Night', 'Acoustic Evening', 'Gospel Praise Concert', 'DJ Battle', 'Open Mic Live', 'Jazz Under the Stars'],
      Career: ['Career Fair', 'CV Clinic', 'Internship Expo', 'Alumni Mentorship Mixer', 'Interview Masterclass', 'Graduate Jobs Day'],
      Sports: ['Football Finals', 'Basketball Tournament', 'Inter-Campus Athletics', 'Volleyball Cup', 'Fun Run 5K', 'Rugby Sevens'],
      Talk: ['Founders Talk', 'Leadership Forum', 'Women in Tech Panel', 'Mental Health Awareness Talk', 'Climate Action Dialogue', 'Finance for Students'],
      Arts: ['Poetry Evening', 'Film Screening', 'Art Exhibition', 'Drama Club Showcase', 'Photography Walk', 'Cultural Day']
    };
    const cats = Object.keys(names);
    const venues = ['Innovation Lab, Block B', 'Main Amphitheatre', 'Auditorium 2', 'Sports Hall', 'Campus Stadium', 'Student Centre Lounge', 'Library Hall', 'Science Block Lab 4'];
    const prices = [0, 0, 200, 300, 500, 800, 1000, 1500], caps = [20, 22, 24, 25, 28, 30, 26];
    const hours = [9, 10, 14, 16, 18, 19];
    const ins = db.prepare("INSERT INTO events(organizer_id,title,category,description,venue,date,price,capacity,status) VALUES(2,?,?,?,?,?,?,?,'published')");
    const t = new Date(), startMs = Date.UTC(t.getFullYear(), t.getMonth(), t.getDate() + 3);
    db.transaction(() => {
      for (let i = 0; i < 100; i++) {
        const cat = cats[i % 6], name = names[cat][Math.floor(i / 6) % 6];
        const title = name + ['', ' - Edition 2', ' - Edition 3'][Math.floor(i / 36)];
        const date = new Date(startMs + Math.round(i * 3.6) * 864e5 + hours[i % 6] * 36e5).toISOString().slice(0, 16);
        ins.run(title, cat, `Join us for ${title}. Open to all students.`, venues[i % 8], date, prices[i % 8], caps[i % 7]);
      }
    })();
    db.pragma('user_version = 2');
  }
  // v3 migration: every event (old or new) holds 20-30 guests
  if ((db.pragma('user_version', { simple: true }) || 0) < 3) {
    db.exec('UPDATE events SET capacity = 20 + (id % 11)');
    db.pragma('user_version = 3');
  }

  const app = express();
  app.use(express.json());
  app.use(express.static('public'));
  app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'index.html'))); // never expose the folder (db file!)

  // ---------- helpers ----------
  const log = (uid, action) => db.prepare('INSERT INTO audit(user_id,action) VALUES(?,?)').run(uid, action);
  const sign = u => jwt.sign({ id: u.id, role: u.role, name: u.name }, SECRET, { expiresIn: '8h' });
  const pubUser = u => ({ id: u.id, role: u.role, name: u.name, email: u.email });
  const auth = (...roles) => (req, res, next) => {
    try {
      const p = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), SECRET);
      const u = db.prepare('SELECT id,name,role,status FROM users WHERE id=?').get(p.id); // live role/status check
      if (!u || u.status !== 'active') return res.status(403).json({ error: 'Account suspended' });
      req.user = { id: u.id, name: u.name, role: u.role };
    } catch { return res.status(401).json({ error: 'Please sign in' }); }
    if (roles.length && !roles.includes(req.user.role)) return res.status(403).json({ error: 'Forbidden' });
    next();
  };
  const optUser = req => { try { return jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), SECRET); } catch { return null; } };
  const hits = new Map();
  const limit = (max, ms) => (req, res, next) => {
    const k = req.ip + req.path, now = Date.now(), arr = (hits.get(k) || []).filter(t => now - t < ms);
    if (arr.length >= max) return res.status(429).json({ error: 'Too many requests. Please wait a few minutes.' });
    arr.push(now); hits.set(k, arr); next();
  };

  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const mask = em => em.replace(/^(.).*?(@.*)$/, '$1***$2');
  const getEvent = id => db.prepare('SELECT * FROM events WHERE id=?').get(id);
  const userEmail = uid => (db.prepare('SELECT email FROM users WHERE id=?').get(uid) || {}).email;
  const canManage = (u, e) => e && (u.role === 'admin' || e.organizer_id === u.id);
  // seats held = accepted guests + waitlist offers waiting for an answer
  const held = id => db.prepare("SELECT COUNT(*) n FROM invitations WHERE event_id=? AND status IN ('accepted','offered')").get(id).n;
  const countStatus = (id, st) => db.prepare('SELECT COUNT(*) n FROM invitations WHERE event_id=? AND status=?').get(id, st).n;
  const ratingOf = id => db.prepare('SELECT ROUND(AVG(rating),1) avg, COUNT(*) n FROM reviews WHERE event_id=?').get(id);
  const decorate = (e, uid) => {
    const r = ratingOf(e.id);
    return { ...e, booked: held(e.id), waitlist: countStatus(e.id, 'waitlist'), rating: r.avg, reviews: r.n,
      fav: uid ? !!db.prepare('SELECT 1 FROM favorites WHERE user_id=? AND event_id=?').get(uid, e.id) : false };
  };

  // ---------- notifications & email ----------
  const notify = (uid, text, link = '') => { if (uid) db.prepare('INSERT INTO notifications(user_id,text,link) VALUES(?,?,?)').run(uid, text, link); };
  const notifyEmail = (em, text, link) => { const u = db.prepare('SELECT id FROM users WHERE email=?').get(em); if (u) notify(u.id, text, link); };
  const BASE_URL = (process.env.BASE_URL || `http://localhost:${process.env.PORT || 3000}`).replace(/\/$/, '');
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) {
    console.error('\nEmail is not configured. Copy env.example to .env, fill in your email settings and start again.\n');
    process.exit(1);
  }
  const mailer = nodemailer.createTransport({
    host: process.env.SMTP_HOST, port: +process.env.SMTP_PORT || 587, secure: +process.env.SMTP_PORT === 465,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS.replace(/\s/g, '') } });
  try { await mailer.verify(); console.log('Email server connected:', process.env.SMTP_HOST); }
  catch (err) { console.error('\nCould not log in to the email server:', err.message, '\nCheck SMTP_USER / SMTP_PASS in your .env file.\n'); process.exit(1); }
  async function sendMail(to, subject, text, html) {
    await mailer.sendMail({ from: process.env.MAIL_FROM || `CampusPass <${process.env.SMTP_USER}>`, to, subject, text, html });
    return true;
  }
  const mailQuiet = (...a) => sendMail(...a).catch(err => console.error('Mail error:', err.message));

  async function sendInvite(inv, ev, promoted) {
    const link = `${BASE_URL}/#accept/${inv.token}`;
    const when = ev.date.replace('T', ' ');
    const intro = promoted ? `Good news! A spot opened up for ${ev.title}.` : `You're invited to ${ev.title}.`;
    const sent = await sendMail(inv.email, promoted ? `A spot opened up: ${ev.title}` : `You're invited: ${ev.title}`,
      `Hi ${inv.name || 'there'},\n\n${intro}\nWhere: ${ev.venue}\nWhen: ${when}\nAccept your invitation to confirm your spot:\n${link}\n`,
      `<p>Hi ${esc(inv.name || 'there')},</p><p>${esc(intro)}</p><p>📍 ${esc(ev.venue)}<br>📅 ${esc(when)}</p>
       <p><a href="${link}" style="background:#6D28D9;color:#fff;padding:12px 20px;border-radius:12px;text-decoration:none;font-weight:600">Accept invitation</a></p>
       <p style="color:#666;font-size:13px">Or paste this link: ${link}</p>`);
    return { link, sent };
  }

  // when a seat frees up, offer it to the first person on the waitlist
  async function promote(eid) {
    const e = getEvent(eid);
    if (!e || e.status !== 'published') return;
    while (held(eid) < e.capacity) {
      const w = db.prepare("SELECT * FROM invitations WHERE event_id=? AND status='waitlist' ORDER BY id LIMIT 1").get(eid);
      if (!w) break;
      const token = crypto.randomBytes(16).toString('hex');
      db.prepare("UPDATE invitations SET status='offered', token=? WHERE id=?").run(token, w.id);
      notifyEmail(w.email, `A spot opened up for ${e.title}! Check your email to accept it.`, 'tickets');
      await sendInvite({ ...w, token }, e, true).catch(err => console.error('Mail error:', err.message));
    }
  }

  // ---------- Auth & profile ----------
  app.post('/api/register', limit(10, 600000), (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !EMAIL_RE.test(email || '') || !password || password.length < 6) return res.status(400).json({ error: 'Name, valid email and 6+ char password required' });
    try {
      const r = db.prepare('INSERT INTO users(name,email,hash) VALUES(?,?,?)').run(name.trim(), email.toLowerCase(), bcrypt.hashSync(password, 8));
      const u = { id: r.lastInsertRowid, role: 'student', name: name.trim(), email: email.toLowerCase() };
      res.json({ token: sign(u), user: u });
    } catch { res.status(409).json({ error: 'Email already registered' }); }
  });
  app.post('/api/login', limit(20, 600000), (req, res) => {
    const u = db.prepare('SELECT * FROM users WHERE email=?').get((req.body.email || '').toLowerCase());
    if (!u || !bcrypt.compareSync(req.body.password || '', u.hash)) return res.status(401).json({ error: 'Invalid credentials' });
    if (u.status !== 'active') return res.status(403).json({ error: 'Account suspended' });
    res.json({ token: sign(u), user: pubUser(u) });
  });
  app.put('/api/me', auth(), (req, res) => {
    const { name, password, current } = req.body;
    const u = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
    if (name && name.trim()) db.prepare('UPDATE users SET name=? WHERE id=?').run(name.trim(), u.id);
    if (password) {
      if (password.length < 6) return res.status(400).json({ error: 'New password needs 6+ characters' });
      if (!bcrypt.compareSync(current || '', u.hash)) return res.status(400).json({ error: 'Current password is wrong' });
      db.prepare('UPDATE users SET hash=? WHERE id=?').run(bcrypt.hashSync(password, 8), u.id);
    }
    const n = db.prepare('SELECT * FROM users WHERE id=?').get(u.id);
    log(u.id, 'updated profile');
    res.json({ token: sign(n), user: pubUser(n) });
  });

  // ---------- Events: browse ----------
  app.get('/api/events', (req, res) => {
    const { q = '', category = '', when = '', sort = 'date', free = '', fav = '' } = req.query;
    const me = optUser(req);
    let rows = db.prepare("SELECT * FROM events WHERE status='published' AND (title LIKE ? OR venue LIKE ?) AND (?='' OR category=?) AND (?=0 OR price=0) ORDER BY date")
      .all(`%${q}%`, `%${q}%`, category, category, free ? 1 : 0);
    const now = new Date(), end = { today: 1, week: 7, month: 30, quarter: 90 }[when];
    if (end) rows = rows.filter(e => { const d = (new Date(e.date) - now) / 864e5; return d >= -1 && d <= end; });
    let out = rows.map(e => decorate(e, me && me.id));
    if (fav && me) out = out.filter(e => e.fav);
    const by = {
      popular: (a, b) => b.booked - a.booked, rating: (a, b) => (b.rating || 0) - (a.rating || 0),
      price: (a, b) => a.price - b.price, spots: (a, b) => (a.capacity - a.booked) - (b.capacity - b.booked) }[sort];
    if (by) out.sort(by);
    res.json(out);
  });
  app.get('/api/events/:id', (req, res) => {
    const e = getEvent(req.params.id);
    if (!e) return res.status(404).json({ error: 'Not found' });
    const me = optUser(req), out = decorate(e, me && me.id);
    if (me) {
      const em = userEmail(me.id), inv = db.prepare('SELECT status FROM invitations WHERE event_id=? AND email=?').get(e.id, em);
      out.mine = inv ? inv.status : null;
      out.canReview = inv && inv.status === 'accepted' && new Date(e.date) < new Date();
    }
    res.json(out);
  });
  app.get('/api/events/:id/attendees', (req, res) => {
    const rows = db.prepare("SELECT name,email,accepted_at FROM invitations WHERE event_id=? AND status='accepted' ORDER BY accepted_at").all(req.params.id);
    res.json({ attendees: rows.map(r => ({ name: r.name || mask(r.email), email: mask(r.email), at: r.accepted_at })),
      pending: countStatus(req.params.id, 'pending') + countStatus(req.params.id, 'offered'), waitlist: countStatus(req.params.id, 'waitlist') });
  });
  app.get('/api/events/:id/ics', (req, res) => { // add to calendar
    const e = getEvent(req.params.id);
    if (!e || e.status === 'pending') return res.status(404).json({ error: 'Not found' });
    const [d, t] = e.date.split('T'), [y, m, dd] = d.split('-').map(Number), [h, mi] = (t || '09:00').split(':').map(Number);
    const stamp = (add) => new Date(Date.UTC(y, m - 1, dd, h + add, mi)).toISOString().replace(/[-:]/g, '').slice(0, 15);
    const tx = s => String(s || '').replace(/[\\;,]/g, c => '\\' + c).replace(/\r?\n/g, '\\n');
    res.set({ 'Content-Type': 'text/calendar; charset=utf-8', 'Content-Disposition': `attachment; filename="event-${e.id}.ics"` });
    res.send(['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//CampusPass//EN', 'BEGIN:VEVENT', `UID:event-${e.id}@campuspass`,
      `DTSTAMP:${stamp(0)}Z`, `DTSTART:${stamp(0)}`, `DTEND:${stamp(2)}`, `SUMMARY:${tx(e.title)}`, `LOCATION:${tx(e.venue)}`,
      `DESCRIPTION:${tx(e.description)}`, 'END:VEVENT', 'END:VCALENDAR'].join('\r\n'));
  });
  app.post('/api/events/:id/favorite', auth(), (req, res) => {
    const has = db.prepare('SELECT 1 FROM favorites WHERE user_id=? AND event_id=?').get(req.user.id, req.params.id);
    has ? db.prepare('DELETE FROM favorites WHERE user_id=? AND event_id=?').run(req.user.id, req.params.id)
        : db.prepare('INSERT INTO favorites(user_id,event_id) VALUES(?,?)').run(req.user.id, req.params.id);
    res.json({ fav: !has });
  });

  // ---------- Reviews ----------
  app.get('/api/events/:id/reviews', (req, res) => res.json(db.prepare(
    'SELECT r.rating,r.comment,r.created,u.name FROM reviews r JOIN users u ON u.id=r.user_id WHERE r.event_id=? ORDER BY r.id DESC LIMIT 50').all(req.params.id)));
  app.post('/api/events/:id/reviews', auth(), (req, res) => {
    const e = getEvent(req.params.id), rating = Math.round(+req.body.rating);
    if (!e) return res.status(404).json({ error: 'Not found' });
    if (!(rating >= 1 && rating <= 5)) return res.status(400).json({ error: 'Rating must be 1 to 5' });
    if (new Date(e.date) > new Date()) return res.status(400).json({ error: 'You can review after the event has taken place' });
    if (!db.prepare("SELECT 1 FROM invitations WHERE event_id=? AND email=? AND status='accepted'").get(e.id, userEmail(req.user.id)))
      return res.status(403).json({ error: 'Only guests who attended can review' });
    db.prepare('INSERT INTO reviews(event_id,user_id,rating,comment) VALUES(?,?,?,?) ON CONFLICT(event_id,user_id) DO UPDATE SET rating=excluded.rating, comment=excluded.comment')
      .run(e.id, req.user.id, rating, (req.body.comment || '').slice(0, 500));
    notify(e.organizer_id, `New ${rating}★ review on ${e.title}`, 'org');
    res.json({ ok: true });
  });

  // ---------- Invitations (email flow, waitlist) ----------
  app.post('/api/events/:id/invite', limit(8, 600000), async (req, res) => {
    const email = (req.body.email || '').trim().toLowerCase(), name = (req.body.name || '').trim().slice(0, 80);
    if (!EMAIL_RE.test(email)) return res.status(400).json({ error: 'Enter a valid email address' });
    const e = db.prepare("SELECT * FROM events WHERE id=? AND status='published'").get(req.params.id);
    if (!e) return res.status(404).json({ error: 'Event not found' });
    let inv = db.prepare('SELECT * FROM invitations WHERE event_id=? AND email=?').get(e.id, email);
    if (inv && inv.status === 'accepted') return res.status(409).json({ error: 'This email is already on the guest list' });
    if (inv && inv.status === 'waitlist') return res.status(409).json({ error: 'This email is already on the waitlist' });
    const full = held(e.id) >= e.capacity && !(inv && inv.status === 'offered');
    const token = crypto.randomBytes(16).toString('hex'), status = full ? 'waitlist' : (inv && inv.status === 'offered' ? 'offered' : 'pending');
    if (!inv) {
      const r = db.prepare('INSERT INTO invitations(event_id,email,name,token,status) VALUES(?,?,?,?,?)').run(e.id, email, name, token, status);
      inv = { id: r.lastInsertRowid, event_id: e.id, email, name, token };
    } else {
      db.prepare("UPDATE invitations SET status=?, token=?, name=COALESCE(NULLIF(?,''),name) WHERE id=?").run(status, token, name, inv.id);
      inv = { ...inv, token, name: name || inv.name };
    }
    if (full) {
      const pos = db.prepare("SELECT COUNT(*) n FROM invitations WHERE event_id=? AND status='waitlist' AND id<=?").get(e.id, inv.id).n;
      notifyEmail(email, `You're #${pos} on the waitlist for ${e.title}`, 'tickets');
      return res.json({ ok: true, waitlisted: true, position: pos });
    }
    try {
      const m = await sendInvite(inv, e, false);
      res.json({ ok: true, emailed: m.sent });
    } catch (err) {
      console.error('Mail error:', err.message);
      res.status(502).json({ error: 'Could not send the email. Please try again.' });
    }
  });
  app.post('/api/invitations/accept', (req, res) => {
    const inv = db.prepare('SELECT i.*, e.title, e.capacity, e.organizer_id, e.status estatus FROM invitations i JOIN events e ON e.id=i.event_id WHERE i.token=?').get(req.body.token || '');
    if (!inv) return res.status(404).json({ error: 'This invitation link is invalid or has been replaced' });
    if (inv.estatus === 'cancelled') return res.status(410).json({ error: 'This event was cancelled' });
    if (inv.status === 'cancelled') return res.status(410).json({ error: 'This invitation was cancelled' });
    if (inv.status === 'waitlist') return res.status(400).json({ error: 'You are still on the waitlist. We will email you if a spot opens.' });
    if (inv.status === 'pending' && held(inv.event_id) >= inv.capacity) return res.status(409).json({ error: 'Sorry, the event is now full. Join the waitlist from the event page.' });
    if (inv.status !== 'accepted') {
      db.prepare("UPDATE invitations SET status='accepted', accepted_at=CURRENT_TIMESTAMP WHERE id=?").run(inv.id);
      notify(inv.organizer_id, `${inv.name || mask(inv.email)} accepted the invitation to ${inv.title}`, 'org');
      notifyEmail(inv.email, `You're confirmed for ${inv.title}`, 'event/' + inv.event_id);
    }
    res.json({ ok: true, event_id: inv.event_id, event: inv.title, email: inv.email, name: inv.name || mask(inv.email) });
  });
  app.get('/api/invitations/mine', auth(), (req, res) => res.json(db.prepare(
    `SELECT i.id,i.status,i.event_id,i.accepted_at,e.title,e.venue,e.date,e.status estatus FROM invitations i JOIN events e ON e.id=i.event_id
     WHERE i.email=? AND i.status!='cancelled' ORDER BY e.date`).all(userEmail(req.user.id))));
  app.delete('/api/invitations/:id', auth(), (req, res) => {
    const inv = db.prepare('SELECT * FROM invitations WHERE id=? AND email=?').get(req.params.id, userEmail(req.user.id));
    if (!inv || inv.status === 'cancelled') return res.status(400).json({ error: 'Cannot cancel' });
    db.prepare("UPDATE invitations SET status='cancelled' WHERE id=?").run(inv.id);
    if (inv.status === 'accepted' || inv.status === 'offered') promote(inv.event_id);
    res.json({ ok: true });
  });

  // ---------- Notifications ----------
  app.get('/api/notifications', auth(), (req, res) => res.json({
    items: db.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 40').all(req.user.id),
    unread: db.prepare('SELECT COUNT(*) n FROM notifications WHERE user_id=? AND read=0').get(req.user.id).n }));
  app.post('/api/notifications/read', auth(), (req, res) => {
    db.prepare('UPDATE notifications SET read=1 WHERE user_id=?').run(req.user.id); res.json({ ok: true });
  });

  // ---------- Organizer ----------
  const eventFields = b => {
    const f = { title: (b.title || '').trim(), category: b.category || 'Other', description: (b.description || '').trim(),
      venue: (b.venue || '').trim(), date: b.date, price: Math.max(0, +b.price || 0), capacity: Math.floor(+b.capacity) };
    if (!f.title || !f.venue || !f.date) return { error: 'Title, venue and date required' };
    if (!(f.capacity >= 1 && f.capacity <= MAX_CAP)) return { error: `Capacity must be between 1 and ${MAX_CAP}` };
    return { f };
  };
  app.post('/api/events', auth('organizer', 'admin'), (req, res) => {
    const { f, error } = eventFields(req.body);
    if (error) return res.status(400).json({ error });
    const r = db.prepare('INSERT INTO events(organizer_id,title,category,description,venue,date,price,capacity) VALUES(?,?,?,?,?,?,?,?)')
      .run(req.user.id, f.title, f.category, f.description, f.venue, f.date, f.price, f.capacity);
    log(req.user.id, `created event ${r.lastInsertRowid}`);
    db.prepare("SELECT id FROM users WHERE role='admin'").all().forEach(a => notify(a.id, `New event awaiting approval: ${f.title}`, 'admin'));
    res.json({ id: r.lastInsertRowid, status: 'pending' });
  });
  app.put('/api/events/:id', auth('organizer', 'admin'), (req, res) => {
    const e = getEvent(req.params.id);
    if (!canManage(req.user, e)) return res.status(403).json({ error: 'Forbidden' });
    if (e.status === 'cancelled') return res.status(400).json({ error: 'Cancelled events cannot be edited' });
    const { f, error } = eventFields(req.body);
    if (error) return res.status(400).json({ error });
    if (f.capacity < held(e.id)) return res.status(400).json({ error: `Capacity cannot be below the ${held(e.id)} guests already confirmed` });
    db.prepare('UPDATE events SET title=?,category=?,description=?,venue=?,date=?,price=?,capacity=? WHERE id=?')
      .run(f.title, f.category, f.description, f.venue, f.date, f.price, f.capacity, e.id);
    if (f.date !== e.date || f.venue !== e.venue) {
      db.prepare("SELECT email,name FROM invitations WHERE event_id=? AND status='accepted'").all(e.id).forEach(g => {
        notifyEmail(g.email, `${f.title} was updated: now ${f.date.replace('T', ' ')} at ${f.venue}`, 'event/' + e.id);
        mailQuiet(g.email, `Update: ${f.title}`, `Hi ${g.name || 'there'},\n\n${f.title} has been updated.\nNew time: ${f.date.replace('T', ' ')}\nVenue: ${f.venue}\n`);
      });
    }
    log(req.user.id, `edited event ${e.id}`);
    promote(e.id);
    res.json({ ok: true });
  });
  app.post('/api/events/:id/cancel', auth('organizer', 'admin'), (req, res) => {
    const e = getEvent(req.params.id);
    if (!canManage(req.user, e)) return res.status(403).json({ error: 'Forbidden' });
    db.prepare("UPDATE events SET status='cancelled' WHERE id=?").run(e.id);
    db.prepare("SELECT email,name FROM invitations WHERE event_id=? AND status IN ('accepted','pending','offered','waitlist')").all(e.id).forEach(g => {
      notifyEmail(g.email, `${e.title} has been cancelled`, 'tickets');
      mailQuiet(g.email, `Cancelled: ${e.title}`, `Hi ${g.name || 'there'},\n\nWe're sorry, ${e.title} on ${e.date.replace('T', ' ')} has been cancelled.\n`);
    });
    log(req.user.id, `cancelled event ${e.id}`);
    res.json({ ok: true });
  });
  app.post('/api/organizer/events/:id/announce', auth('organizer', 'admin'), (req, res) => {
    const e = getEvent(req.params.id), msg = (req.body.message || '').trim().slice(0, 1000);
    if (!canManage(req.user, e)) return res.status(403).json({ error: 'Forbidden' });
    if (!msg) return res.status(400).json({ error: 'Write a message first' });
    const guests = db.prepare("SELECT email,name FROM invitations WHERE event_id=? AND status='accepted'").all(e.id);
    guests.forEach(g => {
      notifyEmail(g.email, `📣 ${e.title}: ${msg}`, 'event/' + e.id);
      mailQuiet(g.email, `Announcement: ${e.title}`, `Hi ${g.name || 'there'},\n\n${msg}\n\n- ${req.user.name}, organizer of ${e.title}`);
    });
    log(req.user.id, `announcement to ${guests.length} guests of event ${e.id}`);
    res.json({ ok: true, sent: guests.length });
  });
  app.get('/api/organizer/events/:id/attendees', auth('organizer', 'admin'), (req, res) => {
    const e = getEvent(req.params.id);
    if (!canManage(req.user, e)) return res.status(403).json({ error: 'Forbidden' });
    res.json(db.prepare("SELECT id,name,email,status,created,accepted_at,checked_in FROM invitations WHERE event_id=? AND status!='cancelled' ORDER BY id").all(e.id));
  });
  app.get('/api/organizer/events/:id/export', auth('organizer', 'admin'), (req, res) => {
    const e = getEvent(req.params.id);
    if (!canManage(req.user, e)) return res.status(403).json({ error: 'Forbidden' });
    const q = v => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const rows = db.prepare("SELECT name,email,status,created,accepted_at,checked_in FROM invitations WHERE event_id=? AND status!='cancelled' ORDER BY id").all(e.id);
    res.set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="guests-event-${e.id}.csv"` });
    res.send(['Name,Email,Status,Invited,Accepted,Checked in', ...rows.map(r => [r.name, r.email, r.status, r.created, r.accepted_at, r.checked_in ? 'yes' : 'no'].map(q).join(','))].join('\n'));
  });
  const guestOwner = (req) => {
    const inv = db.prepare('SELECT * FROM invitations WHERE id=?').get(req.params.id);
    return inv && canManage(req.user, getEvent(inv.event_id)) ? inv : null;
  };
  app.post('/api/organizer/invitations/:id/checkin', auth('organizer', 'admin'), (req, res) => { // manual check-in at the door
    const inv = guestOwner(req);
    if (!inv || inv.status !== 'accepted') return res.status(400).json({ error: 'Only accepted guests can be checked in' });
    db.prepare('UPDATE invitations SET checked_in=? WHERE id=?').run(inv.checked_in ? 0 : 1, inv.id);
    res.json({ checked_in: !inv.checked_in });
  });
  app.delete('/api/organizer/invitations/:id', auth('organizer', 'admin'), (req, res) => {
    const inv = guestOwner(req);
    if (!inv) return res.status(403).json({ error: 'Forbidden' });
    db.prepare("UPDATE invitations SET status='cancelled' WHERE id=?").run(inv.id);
    const e = getEvent(inv.event_id);
    notifyEmail(inv.email, `You were removed from the guest list of ${e.title}`, 'tickets');
    log(req.user.id, `removed guest ${inv.id} from event ${e.id}`);
    if (inv.status === 'accepted' || inv.status === 'offered') promote(e.id);
    res.json({ ok: true });
  });
  app.get('/api/organizer/dashboard', auth('organizer', 'admin'), (req, res) => {
    const out = db.prepare('SELECT * FROM events WHERE organizer_id=? ORDER BY date').all(req.user.id).map(e => {
      const s = db.prepare(`SELECT COALESCE(SUM(CASE WHEN status='accepted' THEN 1 END),0) booked, COALESCE(SUM(CASE WHEN status IN ('pending','offered') THEN 1 END),0) pending,
        COALESCE(SUM(CASE WHEN status='waitlist' THEN 1 END),0) waitlist, COALESCE(SUM(CASE WHEN status='accepted' AND checked_in=1 THEN 1 END),0) checked FROM invitations WHERE event_id=?`).get(e.id);
      const r = ratingOf(e.id);
      return { ...e, ...s, revenue: s.booked * e.price, rating: r.avg, reviews: r.n };
    });
    const sum = k => out.reduce((a, e) => a + e[k], 0);
    res.json({ events: out, totals: { accepted: sum('booked'), pending: sum('pending'), waitlist: sum('waitlist'), checkedIn: sum('checked'), revenue: sum('revenue') } });
  });

  // ---------- Admin ----------
  app.get('/api/admin/overview', auth('admin'), (req, res) => res.json({
    users: db.prepare('SELECT id,name,email,role,status,created FROM users ORDER BY id').all(),
    pending: db.prepare("SELECT * FROM events WHERE status='pending'").all(),
    events: db.prepare("SELECT id,title,status,date FROM events WHERE status IN ('published','pending') ORDER BY id DESC LIMIT 30").all(),
    audit: db.prepare('SELECT * FROM audit ORDER BY id DESC LIMIT 20').all() }));
  app.get('/api/admin/analytics', auth('admin'), (req, res) => {
    const g = 'LEFT JOIN invitations i ON i.event_id=e.id';
    res.json({
      users: db.prepare('SELECT role, COUNT(*) n FROM users GROUP BY role').all(),
      events: db.prepare('SELECT status, COUNT(*) n FROM events GROUP BY status').all(),
      invites: db.prepare('SELECT status, COUNT(*) n FROM invitations GROUP BY status').all(),
      categories: db.prepare(`SELECT e.category name, COALESCE(SUM(CASE WHEN i.status='accepted' THEN 1 END),0) n FROM events e ${g} GROUP BY e.category ORDER BY n DESC`).all(),
      top: db.prepare(`SELECT e.title name, COALESCE(SUM(CASE WHEN i.status='accepted' THEN 1 END),0) n FROM events e ${g} GROUP BY e.id ORDER BY n DESC, e.id LIMIT 5`).all() });
  });
  app.post('/api/admin/events/:id/:action', auth('admin'), (req, res) => {
    const st = { approve: 'published', reject: 'rejected' }[req.params.action], e = getEvent(req.params.id);
    if (!st || !e) return res.status(400).json({ error: 'Bad action' });
    db.prepare('UPDATE events SET status=? WHERE id=?').run(st, e.id);
    const why = (req.body.reason || '').trim().slice(0, 300);
    notify(e.organizer_id, st === 'published' ? `Your event "${e.title}" was approved and is live!` : `Your event "${e.title}" was rejected${why ? ': ' + why : ''}`, 'org');
    log(req.user.id, `${req.params.action} event ${e.id}${why ? ' (' + why + ')' : ''}`);
    res.json({ ok: true });
  });
  app.post('/api/admin/users/:id/status', auth('admin'), (req, res) => {
    if (+req.params.id === req.user.id) return res.status(400).json({ error: "You can't suspend yourself" });
    const st = req.body.status === 'suspended' ? 'suspended' : 'active';
    db.prepare('UPDATE users SET status=? WHERE id=?').run(st, req.params.id);
    log(req.user.id, `set user ${req.params.id} ${st}`); res.json({ ok: true });
  });
  app.post('/api/admin/users/:id/role', auth('admin'), (req, res) => {
    if (+req.params.id === req.user.id) return res.status(400).json({ error: "You can't change your own role" });
    if (!['student', 'organizer', 'admin'].includes(req.body.role)) return res.status(400).json({ error: 'Bad role' });
    db.prepare('UPDATE users SET role=? WHERE id=?').run(req.body.role, req.params.id);
    notify(+req.params.id, `Your role is now ${req.body.role}`, '');
    log(req.user.id, `set user ${req.params.id} role ${req.body.role}`); res.json({ ok: true });
  });

  app.listen(process.env.PORT || 3000, () => console.log(`CampusPass running on http://localhost:${process.env.PORT || 3000}`));
}

start().catch(err => {
  console.error(err);
  process.exit(1);
});
