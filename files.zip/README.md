# CampusPass – Student Event Ticketing System
Node.js + Express + SQLite backend, vanilla JS frontend (violet/pink design system, Plus Jakarta Sans).

## Run
    npm install
    npm start        # http://localhost:3000

Demo logins (password `password123`): amani@students.ac.ke (student), organizer@students.ac.ke, admin@campus.ac.ke.
Set `JWT_SECRET` in production.

## Features
Events hold 20-30 guests each. Email invitations with waitlist, favourites, alerts, reviews, calendar export, organizer tools (edit, cancel, announce, guest list, check-in, CSV) and an admin analytics dashboard.
Existing databases are migrated automatically on next start (capacities become 20-30). To reset everything, stop the server and delete `campuspass.db`.

## Email setup (required)
1. Copy `env.example` to `.env` (`copy env.example .env`) and fill in your email details (Gmail needs an App password).
2. `npm install` then `npm start`. The server checks the email login at startup and stops with a clear message if it is wrong.
3. Set `BASE_URL` to the address guests will open from the email link (localhost only works on your own computer).
